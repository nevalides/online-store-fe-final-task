import React, { useEffect } from "react";
import { FiTrash2 } from "react-icons/fi";
import {
  IoMdAdd,
  IoMdArrowForward,
  IoMdClose,
  IoMdRemove,
} from "react-icons/io";

function Sidebar({ cart, setCart, sidebarState, handleClick }) {
  return (
    <div
      className={`
      ${sidebarState ? "right-0" : "-right-full"}
       w-full bg-white fixed top-0 h-full shadow-2xl md:w-[35vw] lg:w-[40vw] xl:max-w-[30vw] transition-all duration-300 z-20 px-4 lg:px-[35px]`}
    >
      <div className="flex items-center justify-between py-6 border-b">
        <div
          className="cursor-pointer w-8 h-8 flex justify-center items-center"
          onClick={handleClick}
        >
          <IoMdArrowForward className="text-2xl" />
        </div>
      </div>
      <div className="flex flex-col gap-y-2 h-[360px] md:h-[480px] lg:h-[420px] overflow-y-auto overflow-x-hidden border-b">
        <div className="flex gap-x-4 py-2 lg:px-6 border-b border-gray-200 w-full font-light text-gray-500">
          <div className="w-full min-h-[150px] flex items-center gap-x-4">
            <div>
              <img
                className="max-w-[80px]"
                src={
                  "https://opportunitymarketing.co.uk/wp-content/uploads/2020/01/Product_Marketing-1030x586.jpg"
                }
                alt=""
              />
            </div>
            <div className="w-full flex flex-col">
              <div className="flex justify-between mb-2">
                <div className="text-sm uppercase font-medium max-w-[240px] text-primary hover:underline">
                  Title
                </div>
                <div className="text-xl cursor-pointer">
                  <IoMdClose className="text-gray-500 hover:text-red-500 transition" />
                </div>
              </div>
              <div className="flex gap-x-2 h-[36px] text-sm">
                <div className="flex flex-1 max-w-[100px] items-center h-full border text-primary font-medium">
                  <div className="h-full flex-1 flex justify-center items-center cursor-pointer">
                    <IoMdRemove />
                  </div>
                  <div className="h-full flex justify-center items-center px-2">
                    20
                  </div>
                  <div className="h-full flex flex-1 justify-center items-center cursor-pointer">
                    <IoMdAdd />
                  </div>
                </div>
                {/* item price */}
                <div className="flex flex-1 justify-around items-center">
                  $ {100000}
                </div>
                {/* final price */}
                <div className="flex flex-1 justify-end items-center text-primary font-medium">{`$ ${parseFloat(
                  2000000
                ).toFixed(2)}`}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-y-3  mt-4">
        <div className="flex w-full justify-between items-center">
          <div className="font-semibold">
            <span className="mr-2">Subtotal:</span> $ T200000
          </div>
          <div className="cursor-pointer py-4 bg-red-500 text-white w-12 h-12 flex justify-center items-center text-xl">
            <FiTrash2 />
          </div>
        </div>
        <button className="bg-primary flex p-3 justify-center items-center text-white w-full font-medium">
          Checkout
        </button>
      </div>
    </div>
  );
}

export default Sidebar;
